import time
from loguru import logger
from web3 import Web3

from abis.abi import token_abi
from all_info.info import scans


def build_tx(w3, address, chain, contract_address, abi, func=None, value=0, args=None) -> dict:
    contract = w3.eth.contract(address=Web3.to_checksum_address(contract_address), abi=abi)
    nonce = w3.eth.get_transaction_count(address)

    try:

        func_ = getattr(contract.functions, func)
        tx = func_(*args).build_transaction({
            'from': address,
            'nonce': nonce,
            'value': value,
            'maxFeePerGas': int(w3.eth.gas_price * 1.5),
            'maxPriorityFeePerGas': int(w3.eth.gas_price)
        })
        tx['gas'] = int(w3.eth.estimate_gas(tx) * 1.5)
        if chain == 'bsc':
            del tx['maxFeePerGas']
            del tx['maxPriorityFeePerGas']
            tx['gasPrice'] = w3.eth.gas_price

        return tx

    except Exception as e:
        error = str(e)
        if 'INTERNAL_ERROR: insufficient funds' in error or 'insufficient funds for gas' in error:
            logger.error(f'{address}:{chain} - не хватает денег на газ, заканчиваю работу через 5 секунд...')
            time.sleep(5)
            return False
        if 'insufficient funds for transfer' in error:
            logger.error(f'{address}:{chain} - закончились деньги на комиссию...')
        else:
            logger.error(f'{address}:{chain} - {e}')
            return False


def build_tx_with_data(w3, address, chain, contract_address, value=0, data='0x') -> dict:
    try:
        nonce = w3.eth.get_transaction_count(address)
        tx = {
            'from': address,
            'to': contract_address,
            'nonce': nonce,
            'value': value,
            'data': data,
            'chainId': w3.eth.chain_id,
            'maxFeePerGas': int(w3.eth.gas_price * 1.5),
            'maxPriorityFeePerGas': int(w3.eth.gas_price)
        }
        tx['gas'] = w3.eth.estimate_gas(tx)
        if chain == 'bsc':
            del tx['maxFeePerGas']
            del tx['maxPriorityFeePerGas']
            tx['gasPrice'] = w3.eth.gas_price

        return tx
    except Exception as e:
        error = str(e)
        if 'INTERNAL_ERROR: insufficient funds' in error or 'insufficient funds for gas' in error:
            logger.error(f'{address}:{chain} - не хватает денег на газ, заканчиваю работу через 5 секунд...')
            time.sleep(5)
            return False
        if 'insufficient funds for transfer' in error:
            logger.error(f'{address}:{chain} - закончились деньги на комиссию...')
        else:
            logger.error(f'{address}:{chain} - {e}')
            return False

def get_balance(w3, address, address_contract) -> int:
    contract = w3.eth.contract(address=Web3.to_checksum_address(address_contract), abi=token_abi)
    balance = contract.functions.balanceOf(address).call()
    return balance


def check_status_tx(tx_hash, address, w3, chain):
    logger.info(f'{address}:{chain} - жду подтверждения транзакции  {scans[chain]}{w3.to_hex(tx_hash)}...')

    start_time = int(time.time())
    while True:
        current_time = int(time.time())
        if current_time >= start_time + 100:
            logger.info(
                f'{address}:{chain} - транзакция не подтвердилась за 100 cекунд, начинаю повторную отправку...')
            return 0
        try:
            status = w3.eth.get_transaction_receipt(tx_hash)['status']
            if status == 1:
                return status
            time.sleep(1)
        except Exception as error:
            time.sleep(1)


def check_allowance(w3, token, address, spender):
    contract = w3.eth.contract(address=Web3.to_checksum_address(token), abi=token_abi)
    allowance = contract.functions.allowance(address, Web3.to_checksum_address(spender)).call()
    return allowance


def approve_token(w3, account, address, chain, token_address, spender, amount, token_name):
    while True:
        contract = w3.eth.contract(address=token_address, abi=token_abi)
        try:
            allowance = check_allowance(w3, token_address, address, spender, )
            if amount > allowance:
                logger.info(f'{address}:{chain} - апруваю {token_name}...')
                tx = build_tx(w3, address, chain, token_address, token_abi, func='approve', args=(spender, amount * 20))
                sign = account.sign_transaction(tx)
                hash_ = w3.eth.send_raw_transaction(sign.rawTransaction)
                status = check_status_tx(hash_, address, w3, chain)
                if status == 1:
                    logger.success(
                        f'{address}:{chain} - апрувнул {token_name} : {scans[chain]}{w3.to_hex(hash_)}...')
                    break
                else:
                    logger.info(
                        f'{address}:{chain} - не смог апрувнуть {token_name} : {scans[chain]}{w3.to_hex(hash_)}...')
            else:
                logger.info(f'{address}:{chain} - уже апрувнуто...')
                break
        except Exception as e:
            logger.error(f'{address}:{chain} - {e}...')
