

"""
настройка!

shuffle - 1 - включена перемешка кошельков, выключена

from amount, to amount  -  выбираете от скольки до скольки рандомно будет бриджиться в dfk в usdc
                           from amount - минимум 2!!!

part_jewel_to_klaytn, part_for_buy_items  -  настройка какая часть баланса будет тратиться для бриджа джевел в клейтн(на комсу в клей)
                                             и какая часть будет тратиться на покупку предметов, чем меньше потратите на предметы чем больше 
                                             
                                             нужно указывать в процентах (там стоят мои числа с которыми при сумме 
                                             2-2.2 бакса получалось где-то 35-40 транз

delay_between_swaps, delay_between_bridges - настройка времени, советую ставить большое! чтобы все работало дольше и выглядело не так палевно

rpcs - для полигона и клейтн вставить свою! https://nodereal.io/ рекомендую либо взять тут фри тариф, его хватит за глаза
                                                        либо купить платку

"""

shuffle = 1

from_amount = 2  # не менять!
to_amount = 2.2

part_jewel_to_klaytn = 40
part_for_buy_items = 7

delay_between_swaps = (20, 50)
delay_between_bridges = (50, 300)

rpcs = {
    'polygon': '',  # брать тут https://nodereal.io/
    'klaytn': '',
    'dfk': 'https://subnets.avax.network/defi-kingdoms/dfk-chain/rpc',

}