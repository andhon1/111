import json
import random
import time
import requests
from fake_useragent import UserAgent
from web3 import Web3
from loguru import logger
from tqdm import tqdm
from eth_utils import *
from eth_abi import *

from all_info.info import scans, synapse_adresses, uniswap_addresses, chainIds, jewel_bridge_addresses, \
    items_bridges, lz_chainIds
from all_info.tokens_info import tokens, token_decimals
from helpers.help import build_tx, build_tx_with_data, get_balance, approve_token
from abis.abi import synapse_abi, uniswap_abi, uniswap_abi_, lz_abi
from dfk_requests.check_output_price import get_quote
from config import from_amount, to_amount, delay_between_swaps, delay_between_bridges, part_for_buy_items, \
    part_jewel_to_klaytn, rpcs


class Help:
    def check_status_tx(self, tx_hash):
        logger.info(
            f'{self.address}:{self.chain} - жду подтверждения транзакции  {scans[self.chain]}{self.w3.to_hex(tx_hash)}...')

        start_time = int(time.time())
        while True:
            current_time = int(time.time())
            if current_time >= start_time + 100:
                logger.info(
                    f'{self.address}:{self.chain} - транзакция не подтвердилась за 100 cекунд, начинаю повторную отправку...')
                return 0
            try:
                status = self.w3.eth.get_transaction_receipt(tx_hash)['status']
                if status == 1:
                    return status
                time.sleep(1)
            except Exception as error:
                time.sleep(1)

    def sleep_indicator(self, sec):
        for i in tqdm(range(sec), desc='жду', bar_format="{desc}: {n_fmt}c / {total_fmt}c {bar}", colour='green'):
            time.sleep(1)


class Farmer(Help):
    def __init__(self, privatekey, chain):
        self.privatekey = privatekey
        self.chain = chain
        self.w3 = Web3(Web3.HTTPProvider(rpcs[self.chain]))
        self.account = self.w3.eth.account.from_key(self.privatekey)
        self.address = self.account.address
        self.info = f'{self.address}:{self.chain}'
        self.lz_txs = 0
        self.delay_between_swaps = delay_between_swaps
        self.delay_between_bridges = delay_between_bridges

    def counter_lz(self):
        self.lz_txs += 1

    def random_time(self, time_):
        return random.randint(time_[0], time_[1])

    def сheck_lz_fee(self, to_chain, contract):
        to_chain_id = lz_chainIds[to_chain]
        lz_endpoint = self.w3.eth.contract(
            address=Web3.to_checksum_address('0x9740FF91F1985D8d2B71494aE1A2f723bb3Ed9E4'), abi=lz_abi)
        fee = \
            lz_endpoint.functions.estimateFees(to_chain_id, Web3.to_checksum_address(contract), '0x', False,
                                               '0x').call()[0]
        return fee

    def wait_for_balanace(self, token, time_=0):
        logger.info(f'{self.address}:{self.chain} - жду пополнения баланса {token}...')

        last_balance = self.w3.eth.get_balance(self.address)
        start_time = int(time.time())
        while True:
            current_time = int(time.time())
            if token in ['gold', 'health_vial', 'mana_vial']:
                if current_time >= start_time + 100:
                    logger.info(f'{self.address}:{self.chain} - {token} не пополнился за 100 секунд...')
                    return False
            try:
                current_balance = get_balance(self.w3, self.address, tokens[token][self.chain])
                if current_balance > last_balance:
                    logger.success(
                        f'{self.address}:{self.chain} - успешно пополнено на {(current_balance - last_balance) / token_decimals[token]} {token}...')
                    return True
                time.sleep(1)
            except Exception as error:
                time.sleep(1)

    def get_quote_uniswap(self, amount):
        ua = UserAgent()
        ua = ua.random
        headers = {
            'authority': 'api.uniswap.org',
            'accept': '*/*',
            'accept-language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
            'origin': 'https://app.uniswap.org',
            'referer': 'https://app.uniswap.org/',
            'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': ua,
        }

        data = '{"tokenInChainId":137,"tokenIn":"MATIC","tokenOutChainId":137,"tokenOut":"0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174",' \
               '"amount":"' + f'{amount}' + '","type":"EXACT_OUTPUT","configs":[{"protocols":["V2","V3","MIXED"],"routingType":"CLASSIC"}]}'

        try:
            response = requests.post('https://api.uniswap.org/v2/quote', data=data, headers=headers)
            if response.status_code == 200:
                res = json.loads(response.text)
                return int(res['quote']['quote'])
        except Exception as e:
            logger.error(f'{self.address} - {e}')
            return False

    def uniswap(self, amount):
        uniswap_address = Web3.to_checksum_address(uniswap_addresses[self.chain])
        uniswap_ = self.w3.eth.contract(address=uniswap_address, abi=uniswap_abi_)
        timestamp = int(time.time() + 600)
        weth = Web3.to_checksum_address(tokens['weth'][self.chain])
        token = Web3.to_checksum_address(tokens['usdc'][self.chain])
        amount_dec = int(amount * 10 ** 6)

        data = self.get_quote_uniswap(amount_dec)
        if data:
            amount_eth = data
        else:
            logger.error(f'{self.info} - ошибка при свапе...')
            return False
        data = uniswap_.encodeABI(fn_name='exactInputSingle',
                                  args=[(weth, token, 500, self.address, amount_eth, int(amount_dec * 0.95), 0)])
        args = timestamp, [data]
        try:
            tx = build_tx(self.w3, self.address, self.chain, uniswap_address, uniswap_abi_, func='multicall',
                          value=amount_eth, args=args)
            if tx:
                tx = tx
            else:
                return False
            sign = self.account.sign_transaction(tx)
            hash_ = self.w3.eth.send_raw_transaction(sign.rawTransaction)
            logger.info(f'\n\n{self.info} - покупаю {amount} usdc на Uniswap...\n\n')
            status = self.check_status_tx(hash_)
            if status == 1:
                logger.success(
                    f'{self.info} - купил {amount} usdc : {scans[self.chain]}{self.w3.to_hex(hash_)} на Uniswap...')
                self.sleep_indicator(random.randint(1, 50))
            else:
                logger.info(f'{self.info} - пробую еще раз...')
                return self.uniswap(amount)

        except Exception as e:
            error = str(e)
            if 'INTERNAL_ERROR: insufficient funds' in error or 'insufficient funds for gas * price + value' in error:
                logger.error(
                    f'{self.address}:{self.chain} - не хватает денег на покупку, заканчиваю работу через 5 секунд...')
                time.sleep(5)
                return False
            if 'nonce too low' in error or 'already known' in error:
                logger.info(f'{self.address}:{self.chain} - ошибка при бридже, пробую еще раз...')
                return self.uniswap(amount)
            else:
                logger.error(f'{self.address}:{self.chain} - {e}')
                return False

    def bridge_to_dfk(self, amount):
        """amount need be in decimals format!"""
        args = self.address, 53935, Web3.to_checksum_address(
            '0xB6c473756050dE474286bED418B77Aeac39B02aF'), 2, 0, amount, int(amount * 0.98), int(time.time() + 600)
        synapse_adress = Web3.to_checksum_address(synapse_adresses[self.chain])
        approve_token(self.w3, self.account, self.address, self.chain,
                      Web3.to_checksum_address(tokens['usdc']['polygon']), synapse_adress, amount, 'usdc')
        self.sleep_indicator(random.randint(5, 20))
        try:
            tx = build_tx(w3=self.w3, address=self.address, chain=self.chain,
                          contract_address=synapse_adress,
                          abi=synapse_abi, func='swapAndRedeem', args=args)
            if tx:
                tx = tx
            else:
                return False
            logger.info(f'\n\n{self.info} - начинаю бридж {amount / 10 ** 6} usdc...\n\n')
            sign = self.account.sign_transaction(tx)
            hash_ = self.w3.eth.send_raw_transaction(sign.rawTransaction)
            status = self.check_status_tx(hash_)
            if status == 1:
                logger.success(
                    f'{self.info} - успешно отправил {amount / 10 ** 6} usdc в dfk {scans[self.chain]}{self.w3.to_hex(hash_)}...')
                return True
            else:
                logger.info(f'{self.info} - пробую еще раз...')
                return self.bridge_to_dfk(amount)

        except Exception as e:
            error = str(e)
            if 'INTERNAL_ERROR: insufficient funds' in error or 'insufficient funds for gas * price + value' in error:
                logger.error(
                    f'{self.address}:{self.chain} - не хватает денег на газ, заканчиваю работу через 5 секунд...')
                time.sleep(5)
                return False
            if 'nonce too low' in error or 'already known' in error:
                logger.info(f'{self.address}:{self.chain} - ошибка при бридже, пробую еще раз...')
                self.bridge_to_dfk(amount)
            else:
                logger.error(f'{self.address}:{self.chain} - {e}')
                return False

    def swap_tokens(self, token1, token2, token1_name, token2_name, amount, count=1):
        token1, token2 = Web3.to_checksum_address(token1), Web3.to_checksum_address(token2)
        if token1_name in ['usdc', 'wjewel']:
            data = get_quote(token1, token2, self.chain)
        else:
            data = get_quote(token2, token1, self.chain)
        if data:
            price_per_token1 = data
        else:
            return False
        uniswap_address = Web3.to_checksum_address(uniswap_addresses[self.chain])
        if token1_name == 'usdc' or token1_name == 'wjewel':
            minAmount = int(amount * price_per_token1 * 0.95)
            approve_token(self.w3, self.account, self.address, self.chain, token1, uniswap_address, amount, token1_name)
            self.sleep_indicator(random.randint(5, 20))
            func = 'swapExactTokensForETH'
            args = amount, minAmount, [token1, token2], self.address, int(time.time() + 600)
            value = 0
        else:
            minAmount = int(int(amount) / 10 ** 18 * price_per_token1 * 0.95)
            if token1_name == 'gold':
                minAmount = int(minAmount * 10 ** 3)
            if token1_name in ['mana_vial', 'health_vial']:  # conversion for tokens with 1 dec
                minAmount = 1 * count
                amount = int(1 / price_per_token1 * count * 1.05 * 10 ** 18)
            func = 'swapExactETHForTokens'
            args = minAmount, [token2, token1], self.address, int(time.time() + 600)
            value = amount
        try:
            tx = build_tx(w3=self.w3, address=self.address, chain=self.chain, contract_address=uniswap_address,
                          abi=uniswap_abi, value=value, func=func, args=args)
            if tx:
                tx = tx
            else:
                return False
            sign = self.account.sign_transaction(tx)
            hash_ = self.w3.eth.send_raw_transaction(sign.rawTransaction)
            status = self.check_status_tx(hash_)
            if status == 1:
                amount_t2 = to_int(hexstr=self.w3.eth.get_transaction_receipt(to_hex(hash_))['logs'][2]['data'].hex()) / \
                            token_decimals[token1_name]
                if token1_name in ['usdc', 'wjewel']:
                    logger.success(
                        f'{self.info} - успешно cвапнул {amount / token_decimals[token1_name]} {token1_name} на {amount_t2} {token2_name} {scans[self.chain]}{self.w3.to_hex(hash_)}...')
                else:
                    logger.success(
                        f'{self.info} - успешно cвапнул {amount / token_decimals[token2_name]} {token2_name} на {amount_t2} {token1_name} {scans[self.chain]}{self.w3.to_hex(hash_)}...')
                return True
            else:
                logger.info(f'{self.info} - пробую еще раз...')
                return self.swap_tokens(token1, token2, token1_name, token2_name, amount)
        except Exception as e:
            error = str(e)
            if 'INTERNAL_ERROR: insufficient funds' in error or 'insufficient funds for gas * price + value' in error:
                logger.error(
                    f'{self.address}:{self.chain} - не хватает денег на газ, заканчиваю работу через 5 секунд...')
                time.sleep(5)
                return False
            if 'nonce too low' in error or 'already known' in error:
                logger.info(f'{self.address}:{self.chain} - ошибка при бридже, пробую еще раз...')
                return self.swap_tokens(token1, token2, token1_name, token2_name, amount)
            else:
                logger.error(f'{self.address}:{self.chain} - {e}')
                return False

    def bridge_jewel(self, to_chain, amount):
        balance = self.w3.eth.get_balance(self.address)
        if amount > balance:
            logger.error(
                f"{self.address} - сумма отправки {amount} jewel превышает баланс {balance / token_decimals['wjewel']}")
            return False
        func = '0xce0b63ce'
        chainId = chainIds[to_chain]
        data = func + encode(['address', 'uint256', 'uint256'], (self.address, chainId, amount)).hex()
        bridge_address = jewel_bridge_addresses[self.chain]
        try:
            tx = build_tx_with_data(self.w3, self.address, self.chain, bridge_address, value=amount, data=data)
            if tx:
                tx = tx
            else:
                return tx
            sign = self.account.sign_transaction(tx)
            hash_ = self.w3.eth.send_raw_transaction(sign.rawTransaction)
            status = self.check_status_tx(hash_)
            if status == 1:
                logger.success(f'{self.info} - успешно отправил {amount / 10 ** 18} jewel в {to_chain}...')
                return True
            else:
                logger.info(f'{self.info} - пробую еще раз...')
                return self.bridge_jewel(to_chain, amount)
        except Exception as e:
            error = str(e)
            if 'INTERNAL_ERROR: insufficient funds' in error or 'insufficient funds for gas * price + value' in error:
                logger.error(
                    f'{self.address}:{self.chain} - не хватает денег на газ, заканчиваю работу через 5 секунд...')
                time.sleep(5)
                return False
            if 'nonce too low' in error or 'already known' in error:
                logger.info(f'{self.address}:{self.chain} - ошибка при бридже, пробую еще раз...')
                return self.bridge_jewel(to_chain, amount)
            else:
                logger.error(f'{self.address}:{self.chain} - {e}')
                return False

    def bridge_items(self, token, amount_, to_chain):
        token_address = Web3.to_checksum_address(tokens[token][self.chain])
        bridge_address = Web3.to_checksum_address(items_bridges[self.chain])
        try:
            approve_token(self.w3, self.account, self.address, self.chain, token_address,
                          bridge_address, amount_ * 5, token)
            lz_id = lz_chainIds[to_chain]
            func = '0xad660825'
            data = func + encode(['uint256', 'address', 'address', 'uint256'],
                                 (lz_id, self.address, token_address, amount_)).hex()
            l0_fee = self.сheck_lz_fee(to_chain, bridge_address)
            tx = build_tx_with_data(self.w3, self.address, self.chain, bridge_address, int(l0_fee * 1.01),
                                    data)
            if tx:
                tx = tx
            else:
                return False
            sign = self.account.sign_transaction(tx)
            hash_ = self.w3.eth.send_raw_transaction(sign.rawTransaction)
            status = self.check_status_tx(hash_)
            if status == 1:
                logger.success(
                    f'{self.info} - успешно отправил {amount_ / token_decimals[token]} {token} в {to_chain} : {scans[self.chain]}{self.w3.to_hex(hash_)}...')
                return True
            else:
                logger.info(f'{self.info} - пробую еще раз...')
                return self.bridge_items(token, amount_, to_chain)
        except Exception as e:
            error = str(e)
            if 'INTERNAL_ERROR: insufficient funds' in error or 'insufficient funds for gas' in error:
                logger.error(
                    f'{self.address}:{self.chain} - не хватает денег на газ, заканчиваю работу через 5 секунд...')
                time.sleep(5)
                return False
            if 'nonce too low' in error or 'already known' in error:
                logger.info(f'{self.address}:{self.chain} - ошибка при бридже, пробую еще раз...')
                return self.bridge_items(token, amount_, to_chain)
            else:
                logger.error(f'{self.address}:{self.chain} - {e}')
                return False

    def start_bridge(self):
        """buy usdc & bridge from polygon to dfk"""

        # check balance
        while True:
            balance = get_balance(self.w3, self.address, tokens['usdc']['polygon'])
            if int(1.9 * 10 ** 6) <= balance < int(to_amount * 10 ** 6):
                bridge = self.bridge_to_dfk(balance)
                if bridge:
                    return True
                else:
                    return False
            if balance > int(to_amount * 10 ** 6):
                amount = int(to_amount * 10 ** 6)
                bridge = self.bridge_to_dfk(amount)
                if bridge:
                    return True
                else:
                    return False
            else:
                amount = round(random.uniform(from_amount, to_amount), 1)
                self.uniswap(amount)

    def bridge_to_klaytn(self):
        """swap usdc on dfk for jewel and bridge jewel from dfk to klaytn, then swap for klay"""
        logger.info(f'\n\n{self.info} - начинаю свап usdc на jewel...\n\n')
        token1 = 'usdc'
        token2 = 'wjewel'
        amount = get_balance(self.w3, self.address,
                             tokens[token1][self.chain])
        swap = self.swap_info(token1, token2, amount)
        if swap:
            jewel_balance = self.w3.eth.get_balance(self.address)
            logger.info(
                f'\n\n{self.info} - начинаю бридж {int(jewel_balance * (part_jewel_to_klaytn / 100)) / 10 ** 18} jewel в klaytn...\n\n')
            bridge = self.bridge_jewel('klaytn', int(jewel_balance * (part_jewel_to_klaytn / 100)))
            if bridge:
                self.chain = 'klaytn'
                self.w3 = Web3(Web3.HTTPProvider(rpcs[self.chain]))
                self.info = f'{self.address}:{self.chain}'
                status = self.wait_for_balanace('wjewel')
                if status:
                    return self.swap_jewel_for_klay()
            else:
                return False

    def swap_jewel_for_klay(self):
        """swap bridged jewel for klay f"""
        token1 = 'wjewel'
        token2 = 'wklay'
        logger.info(f'{self.info} - начинаю свап jewel на klay...')
        amount = get_balance(self.w3, self.address, tokens[token1][self.chain])
        return self.swap_info(token1, token2, amount)

    def buy_and_bridge_items(self):
        """buy tokens and bridge them"""
        jewel_balance_ = self.w3.eth.get_balance(self.address)
        jewel_for_tokens = int(jewel_balance_ * (part_for_buy_items / 100 * 2))  # balance for buy tokens
        logger.info(f'\n\n{self.info} - начинаю покупать gold, mana_vial и health_vial...\n\n')
        tokens_ = ['health_vial', 'mana_vial']
        random.shuffle(tokens_)
        native = 'wjewel'
        for token in tokens_:
            data = self.swap_info(token, native, 1)
            if data:
                self.sleep_indicator(self.random_time(delay_between_swaps))
            else:
                return False
        amount_for_gold = jewel_for_tokens - (jewel_balance_ - self.w3.eth.get_balance(self.address))
        data = self.swap_info('gold', 'wjewel', amount_for_gold)
        if data:
            self.sleep_indicator(self.random_time(delay_between_swaps))
        else:
            return False

        logger.info(f'\n\n{self.info} - начинаю бриджить gold, mana_vial и health_vial в klaytn...\n\n')
        gold_balance = get_balance(self.w3, self.address, tokens['gold'][self.chain])
        gold_parts = []
        parts = random.randint(5, 10)
        for i in range(parts - 1):
            part = round(gold_balance / parts) + (i < gold_balance % parts)
            gold_parts.append(part)
            gold_balance -= part
        gold_ = ['gold' for i in range(len(gold_parts))]
        tokens_ = gold_ + ['health_vial', 'mana_vial']
        random.shuffle(tokens_)
        for token in tokens_:
            if token == 'gold':
                if len(gold_parts) > 0:
                    random_index = random.randint(0, len(gold_parts) - 1)
                    amount = gold_parts.pop(random_index)
            else:
                amount = 1

            res = self.bridge_items(token, amount, 'klaytn')
            if res:
                self.counter_lz()
                self.sleep_indicator(self.random_time(delay_between_bridges))
            else:
                return False

    def just_bridge_items(self):
        chains = ['klaytn', 'dfk']

        errors = 0
        while True:
            to_chain_ = {
                'klaytn': 'dfk',
                'dfk': 'klaytn'
            }
            for chain in chains:
                to_chain = to_chain_[chain]
                self.chain = chain
                self.w3 = Web3(Web3.HTTPProvider(rpcs[self.chain]))
                self.info = f'{self.address}:{self.chain}'
                logger.info(f'\n\n{self.info} - начинаю бриджить gold, mana_vial и health_vial в {to_chain}...\n\n')
                gold_balance = get_balance(self.w3, self.address, tokens['gold'][chain])
                gold_parts = []
                if chain == 'klaytn':
                    m = 2
                else:
                    m = 1
                parts = random.randint(5 * m, 10 * m)
                for i in range(parts - 1):
                    part = round(gold_balance / parts) + (i < gold_balance % parts)
                    gold_parts.append(part)
                    gold_balance -= part
                gold_ = ['gold' for i in range(len(gold_parts))]
                tokens_ = gold_ + ['health_vial', 'mana_vial']
                random.shuffle(tokens_)
                for token in tokens_:
                    if token == 'gold':
                        if len(gold_parts) > 0:
                            random_index = random.randint(0, len(gold_parts) - 1)
                            amount = gold_parts.pop(random_index)
                    else:
                        amount = 1

                    if token == 'mana_vial':
                        mana_balance = get_balance(self.w3, self.address, tokens['mana_vial'][chain])
                        if mana_balance == 0:
                            res = self.wait_for_balanace('mana_vial')
                            if res:
                                pass
                            else:
                                continue

                    if token == 'health_vial':
                        health_balance = get_balance(self.w3, self.address, tokens['health_vial'][chain])
                        if health_balance == 0:
                            res = self.wait_for_balanace('health_vial')
                            if res:
                                pass
                            else:
                                continue

                    if token == 'gold':
                        health_balance = get_balance(self.w3, self.address, tokens['gold'][chain])
                        if health_balance == 0:
                            res = self.wait_for_balanace('gold')
                            if res:
                                pass
                            else:
                                continue

                    res = self.bridge_items(token, amount, to_chain)
                    if res:
                        self.counter_lz()
                        self.sleep_indicator(self.random_time(delay_between_bridges))
                    else:
                        errors += 1
                        if errors == 2:
                            logger.success(f'{self.info} - успешно сделал {self.lz_txs} транзакции...')
                            return self.address, 'success'
                        else:
                            break

                logger.info(f'{self.address} - перерыв между переключением сетей...')
                self.sleep_indicator(random.randint(150, 300))

    def do(self):
        res = self.start_bridge()
        if res:
            self.sleep_indicator(self.random_time(delay_between_bridges))
            self.chain = 'dfk'
            self.w3 = Web3(Web3.HTTPProvider(rpcs[self.chain]))
            self.info = f'{self.address}:{self.chain}'
            status = self.wait_for_balanace('usdc')
            if status:
                funcs = [self.bridge_to_klaytn, self.buy_and_bridge_items]
                for f in funcs:
                    self.chain = 'dfk'
                    self.w3 = Web3(Web3.HTTPProvider(rpcs[self.chain]))
                    self.info = f'{self.address}:{self.chain}'
                    f.__call__()

        return self.just_bridge_items()

    def swap_info(self, token1, token2, amount):
        token1_name = token1  # ''' если свап токена по его балансу, не делать преобразование'''
        token2_name = token2  # - native
        t1 = tokens[token1_name][self.chain]
        t2 = tokens[token2_name][self.chain]
        return self.swap_tokens(t1, t2, token1_name, token2_name, amount)


