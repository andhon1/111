import requests
from web3 import Web3
from loguru import logger
import json


def get_pairAddress(token1, token2, chain):
    side = {
        'dfk': 'crystalvale',
        'klaytn': 'serendale'
    }
    headers = {
        'authority': 'romenet.rometerminal.io',
        'accept': '*/*',
        'accept-language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/json',
        'origin': 'https://app.rometerminal.io',
        'referer': 'https://app.rometerminal.io/',
        'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
    }
    session = requests.session()
    session.headers.update(headers)
    chain_summary = f'{chain}_pair_summary'
    json_data = {
        'operationName': 'getPairSummary',
        'variables': dict(exchange=side[chain], token0Address=token1.lower(),
                          token1Address=token2.lower()),

        'query': 'query getPairSummary($exchange: String!, $token0Address: String!, $token1Address: String!) {\n  '
                 f'{chain_summary}' + '(\n    order_by: {last_24hour_usd_volume: desc_nulls_last}\n    where: {exchange: {'
                                      '_eq: $exchange}, _or: [{token0_address: {_ilike: $token0Address}, token1_address: {_ilike: '
                                      '$token1Address}}, {token0_address: {_ilike: $token1Address}, token1_address: {_ilike: '
                                      '$token0Address}}]}\n    limit: 1\n  ) {\n    token0 {\n      address\n      name\n      symbol\n    '
                                      '  decimals\n      __typename\n    }\n    token1 {\n      address\n      name\n      symbol\n      '
                                      'decimals\n      __typename\n    }\n    pair_address\n    __typename\n  }\n}\n',
    }
    while True:
        try:
            response = session.post('https://romenet.rometerminal.io/v1/graphql', json=json_data)
            if response.status_code == 200:
                text = json.loads(response.text)
                pair_address = text['data'][chain_summary][0]['pair_address']
                return pair_address, session, side[chain]
        except Exception as e:
            logger.error(e)
            return False


def get_quote(token1, token2, chain) -> float:
    data = get_pairAddress(token1, token2, chain)
    if data:
        pair_address, session, side = data
    else:
        return False

    candles = f'{chain}_swap_candles_cached'
    json_data = {
        'operationName': 'LatestPriceQuery',
        'variables': {
            'baseToken': token2.lower(),
            'exchange': side,
            'isUSDView': False,
            'pairAddress': pair_address,
            'quoteToken': token1.lower(),
            'resolution': 60,
        },
        'query': 'query LatestPriceQuery($exchange: String, $pairAddress: String, $baseToken: String, $quoteToken: '
                 'String, $resolution: Int, $isUSDView: Boolean!) {\n  prices:' + f'{candles}(\n    '
                                                                                  'order_by: {candle_start: desc}\n    limit: 1\n    where: {exchange: {_eq: $exchange}, pair_address: '
                                                                                  '{_eq: $pairAddress}, base_token: {_eq: $baseToken}, quote_token: {_eq: $quoteToken}, '
                                                                                  'resolution_seconds: {_eq: $resolution}}\n  ) {\n    candle_start\n    close @skip(if: $isUSDView)\n '
                                                                                  '   high @skip(if: $isUSDView)\n    low @skip(if: $isUSDView)\n    open @skip(if: $isUSDView)\n    '
                                                                                  'close_usd @include(if: $isUSDView)\n    high_usd @include(if: $isUSDView)\n    low_usd @include(if: '
                                                                                  '$isUSDView)\n    open_usd @include(if: $isUSDView)\n    __typename\n  }\n}\n',
    }

    while True:
        try:
            response = session.post('https://romenet.rometerminal.io/v1/graphql', json=json_data)
            if response.status_code == 200:
                text = json.loads(response.text)
                price_output = float(text['data']['prices'][0]['close'])
                return price_output
        except Exception as e:
            logger.error(e)
            return False
