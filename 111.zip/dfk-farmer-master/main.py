import random
from loguru import logger
import csv

from utils import Farmer
from config import shuffle
from all_info.info import keys


def write_to_csv(filename, key, address, result):
    with open(filename, 'a', newline='') as file:
        writer = csv.writer(file)

        if file.tell() == 0:
            writer.writerow(['key', 'address', 'result'])

        writer.writerow([key, address, result])

def main():
    print(f'\n{" " * 32}автор - https://t.me/iliocka{" " * 32}\n')
    if shuffle:
        random.shuffle(keys)
    logger.info(f'Начинаю работу на {len(keys)} кошельках...')
    for key in keys:
        farm = Farmer(key, chain='polygon')
        res = farm.do()
        write_to_csv('result.csv', key, *res)
    logger.success(f'Успешно сделал {len(keys)} кошельков...')
    logger.success(f'бриджитенг закончен...')

if __name__ == '__main__':
    main()
