scans = {
    'polygon': 'https://polygonscan.com/tx/',
    'dfk': 'https://subnets.avax.network/defi-kingdoms/tx/',
    'klaytn': 'https://scope.klaytn.com/tx/'
}

chainIds = {
    'klaytn': 8217,
    'dfk': 53935
}

lz_chainIds = {
    'klaytn': 150,
    'dfk': 115
}

synapse_adresses = {
    'polygon': '0x1c6ae197ff4bf7ba96c66c5fd64cb22450af9cc8',
}

uniswap_addresses = {
    'dfk': '0x3C351E1afdd1b1BC44e931E12D4E05D6125eaeCa',
    'klaytn': '0x9e987e5e9ab872598f601be4acc5ac23f484845e',
    'polygon': '0x68b3465833fb72a70ecdf485e0e4c7bd8665fc45'
}

jewel_bridge_addresses = {
    'dfk': '0x75224b0f245Fe51d5bf47A898DbB6720D4150BA7'
}

items_bridges = {
    'dfk': '0x501CdC4ef10b63219704Bf6aDb785dfccb06deE2',
    'klaytn': '0x6d5b86eac9097ea4a94b2b69cd4854678b89f839'
}

with open("keys.txt", "r") as f:
    keys = [row.strip() for row in f]
