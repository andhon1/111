tokens = {
    'wjewel': {'dfk': '0xCCb93dABD71c8Dad03Fc4CE5559dC3D89F67a260',
               'klaytn': '0x30c103f8f5a3a732dfe2dce1cc9446f545527b43'},
    'wklay': {'klaytn': '0x19Aac5f612f524B754CA7e7c41cbFa2E981A4432'},
    'weth': {'polygon': '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270'},
    'usdc': {'dfk': '0x3AD9DFE640E1A9Cc1D9B0948620820D975c3803a',
             'polygon': '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174'},
    'gold': {'dfk': '0x576C260513204392F0eC0bc865450872025CB1cA',
             'klaytn': '0xe7a1b580942148451e47b92e95aeb8d31b0aca37'},
    'health_vial': {'dfk': '0x591853e01EcFDcF1Bdc9f093423C197BfBBd1A4f',
                    'klaytn': '0xa27c1429a676db902b9f0360686edbb57d0a7b01'},
    'mana_vial': {'dfk': '0x240da5314B05E84392e868aC8f2b80ad6becadd4',
                  'klaytn': '0x8639d64a2088500ec4f20fb5c41a995fe4f1d85a'}

}

token_decimals = {
    'wjewel': 10**18,
    'wklay': 10**18,
    'usdc': 10**18,
    'gold': 10**3,
    'health_vial': 1,
    'mana_vial': 1
}